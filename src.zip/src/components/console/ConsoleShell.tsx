// src/components/console/ConsoleShell.tsx
"use client";

import type { ReactNode } from "react";

/**
 * Mirrors the employer console chrome:
 * - Outer:  min-h-screen bg-[#FEFEFA] flex
 * - Aside:  w-64 bg-[#FEFEFA] border-r border-gray-200 flex flex-col h-screen sticky top-0
 * - Main:   flex-1 bg-[#FEFEFA] overflow-y-auto
 * - Inner:  p-8 > max-w-6xl content width
 *
 * Optional `topbar` renders sticky at the top of the main area, but employer pages typically inline
 * breadcrumbs and headers inside the .p-8 container — so `topbar` is not required.
 */
export function ConsoleShell({
  sidebar,
  children,
  topbar,
}: {
  sidebar: ReactNode;
  children: ReactNode;
  topbar?: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-[#FEFEFA] flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#FEFEFA] border-r border-gray-200 flex flex-col h-screen sticky top-0">
        {sidebar}
      </aside>

      {/* Main */}
      <main className="flex-1 bg-[#FEFEFA] overflow-y-auto">
        {/* Optional sticky topbar if you ever need it */}
        {topbar ? (
          <div className="sticky top-0 z-10 border-b border-gray-200 bg-[#FEFEFA]/90 backdrop-blur">
            {topbar}
          </div>
        ) : null}

        <div className="p-8">
          <div className="max-w-6xl">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
