import type { ReactNode } from "react";
import { ConsoleShell } from "@/components/console/ConsoleShell";
import StudentSidebar from "@/components/student/StudentSidebar";
// NOTE: employer console usually does NOT have a separate topbar; they inline page headers.
// If you want a sticky bar, import StudentTopbar and pass as `topbar={<StudentTopbar/>}`.

export default function StudentLayout({ children }: { children: ReactNode }) {
  return (
    <ConsoleShell sidebar={<StudentSidebar />}>
      {children}
    </ConsoleShell>
  );
}
