import { absoluteUrl } from "@/lib/url";

async function getApplications() {
  const url = await absoluteUrl("/api/student/applications");
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) return [];
  return res.json();
}

export default async function ApplicationsPage() {
  const apps = await getApplications();

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">My Applications</h1>

      {apps.length === 0 ? (
        <div className="rounded-lg border p-6 text-sm text-muted-foreground">
          No applications yet.
        </div>
      ) : (
        <div className="rounded-lg border divide-y">
          {apps.map((a: any) => (
            <a
              key={a.id}
              href={`/student/applications/${a.id}`}
              className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors"
            >
              <div>
                <div className="font-medium">{a.job?.title}</div>
                <div className="text-sm text-muted-foreground">
                  {a.organization?.name ?? "—"} • {new Date(a.updatedAt).toLocaleString()}
                </div>
              </div>
              <span className="text-xs rounded border px-2 py-1">
                {a.status ?? "Pending"}
              </span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
