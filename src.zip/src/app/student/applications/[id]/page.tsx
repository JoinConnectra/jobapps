export const dynamic = "force-dynamic";

import { absoluteUrl } from "@/lib/url";

async function getApplication(id: string) {
  const url = await absoluteUrl(`/api/student/applications/${id}`);
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) return null;
  return res.json();
}

export default async function ApplicationDetail({ params }: { params: { id: string } }) {
  const app = await getApplication(params.id);

  if (!app) {
    return <div className="text-sm text-red-600">Failed to load application.</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <nav className="flex items-center gap-2 text-sm text-gray-500">
          <a href="/student" className="hover:text-gray-700">Student</a>
          <span>/</span>
          <a href="/student/applications" className="hover:text-gray-700">Applications</a>
          <span>/</span>
          <span className="text-gray-900 font-medium">Detail</span>
        </nav>
        <h1 className="mt-2 text-2xl font-semibold">{app.job?.title ?? "Application"}</h1>
        <div className="text-sm text-gray-500">{app.organization?.name ?? "—"}</div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded-lg border p-4 bg-white">
          <div className="font-medium mb-2">Status</div>
          <div className="inline-flex items-center text-xs rounded border border-gray-200 px-2 py-1 bg-white text-gray-700">
            {app.status ?? "Applied"}
          </div>
        </div>

        <div className="rounded-lg border p-4 bg-white">
          <div className="font-medium mb-2">Timestamps</div>
          <div className="text-sm text-gray-700">
            <div><span className="text-gray-500">Applied:</span> {new Date(app.createdAt).toLocaleString()}</div>
            <div><span className="text-gray-500">Last update:</span> {new Date(app.updatedAt).toLocaleString()}</div>
          </div>
        </div>
      </div>

      {app.job?.descriptionMd ? (
        <div className="rounded-lg border p-4 bg-white">
          <div className="font-medium mb-2">Job Description</div>
          <pre className="whitespace-pre-wrap text-sm text-gray-800">{app.job.descriptionMd}</pre>
        </div>
      ) : null}

      {(app.resumeFilename || app.resumeS3Key) ? (
        <div className="rounded-lg border p-4 bg-white">
          <div className="font-medium mb-2">Submitted Resume</div>
          <div className="text-sm text-gray-700">
            <div>Filename: {app.resumeFilename ?? "—"}</div>
            <div>MIME: {app.resumeMime ?? "—"}</div>
            <div>Size: {app.resumeSize ? `${app.resumeSize} bytes` : "—"}</div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
