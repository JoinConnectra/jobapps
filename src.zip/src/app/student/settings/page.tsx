export default function StudentSettingsPage(){
  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-2xl font-semibold">Settings</h1>
      <div className="rounded-lg border p-4 text-sm text-muted-foreground">Notification & privacy preferences coming soon.</div>
    </div>
  );
}
