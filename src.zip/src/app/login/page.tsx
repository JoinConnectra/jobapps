"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { authClient } from "@/lib/auth-client";
import { toast } from "sonner";
import Link from "next/link";
import { ArrowLeft, LogIn } from "lucide-react";

/**
 * Login page:
 * - Signs user in with email & password
 * - Fetches the app user (from /api/auth/get-user)
 * - Redirects to /student if applicant, /dashboard if employer
 */
export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextParam = searchParams.get("next");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Step 1: Sign in
      const result = await authClient.signIn.email({ email, password });
      if (result?.error) {
        toast.error("Invalid email or password");
        setIsLoading(false);
        return;
      }

      // Step 2: Fetch app user to determine role
      const res = await fetch("/api/auth/get-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      let accountType = "applicant";
      if (res.ok) {
        const data = await res.json();
        accountType = data?.accountType || "applicant";
      }

      // Step 3: Redirect
      toast.success("Welcome back!");
      if (nextParam) {
        router.replace(nextParam);
      } else if (accountType === "applicant") {
        router.replace("/student");
      } else {
        router.replace("/dashboard");
      }
    } catch (err) {
      console.error("Login error:", err);
      toast.error("Unexpected error while signing in");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Left Side Image */}
      <div className="w-1/2 h-screen relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('/login_bg.png')" }}
        />
      </div>

      {/* Right Side Form */}
      <div className="w-1/2 h-screen flex items-center justify-center bg-white">
        <div className="w-[420px] space-y-6">
          <Link
            href="/"
            className="absolute left-6 top-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Link>

          <div className="text-center">
            <h1 className="text-2xl font-semibold mb-1">Welcome back</h1>
            <p className="text-sm text-muted-foreground">
              Sign in to access your dashboard
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                required
                className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium">Password</label>
              <input
                type="password"
                required
                className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-10 inline-flex items-center justify-center gap-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              <LogIn className="h-4 w-4" />
              {isLoading ? "Signing in..." : "Sign In"}
            </button>
          </form>

          <div className="text-center text-sm text-muted-foreground">
            Don’t have an account?{" "}
            <Link href="/register" className="underline hover:text-primary">
              Register
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
