import { redirect } from "next/navigation";
export default function StudentIndex(){ redirect("/student/dashboard"); return null; }
